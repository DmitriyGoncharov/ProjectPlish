<!DOCTYPE html>
<html lang="ru"> 
	<head>
<base href="http://dbk4.kiev.ua/" />
<script type="text/javascript">
var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-38613385-1']);
_gaq.push(['_addOrganic', 'search.ua','query']);
_gaq.push(['_addOrganic', 'search.ukr.net','search_query']);
_gaq.push(['_setSiteSpeedSampleRate',100]);
_gaq.push(['_trackPageview']);
(function() {
var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
	})();
</script>

<link href="/assets/site/img/favicon.ico" rel="shortcut icon" type="image/x-icon" />	  
<meta charset="utf-8"/>	
<title>Страница не найдена | Киев, завод ЖБИ ПАО «ДСК-4» в Украине</title> 
<meta name="description" content="Завод железобетонных конструкций и изделий ПАО «ДСК-4». Страница не найдена. Различные виды бетонных конструкций и изделий. Стоимость на сайте."/> 
<link rel="stylesheet" href="/assets/site/css/style.css"/>
<link rel="stylesheet" href="/assets/site/fotorama/fotorama.css"/>
<link rel="stylesheet" href="/assets/site/css/jscrollpane.css"/>

<!--[if IE]>  
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>  
<![endif]-->
<script src="/assets/site/js/jquery-1.7.2.min.js"></script>
<script src="/assets/site/fotorama/fotorama.js"></script>
<script src="/assets/site/js/jcarousel.js"></script>
<script src="/assets/site/js/myquery.js"></script>

	</head>
	<body oncopy="return false" ondrag="return false" ondragdrop="return false" ondragstart="return false">
<!-- Yandex.Metrika counter -->
<script type="text/javascript">
(function (d, w, c) {
    (w[c] = w[c] || []).push(function() {
        try {
            w.yaCounter20902696 = new Ya.Metrika({id:20902696,
                    webvisor:true,
                    clickmap:true,
                    trackLinks:true,
                    accurateTrackBounce:true});
        } catch(e) { }
    });

    var n = d.getElementsByTagName("script")[0],
        s = d.createElement("script"),
        f = function () { n.parentNode.insertBefore(s, n); };
    s.type = "text/javascript";
    s.async = true;
    s.src = (d.location.protocol == "https:" ? "https:" : "http:") + "//mc.yandex.ru/metrika/watch.js";

    if (w.opera == "[object Opera]") {
        d.addEventListener("DOMContentLoaded", f, false);
    } else { f(); }
})(document, window, "yandex_metrika_callbacks");
</script>
<noscript><div><img src="//mc.yandex.ru/watch/20902696" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->

<div id="fb-root"></div> 
<script>(function(d, s, id) { 
var js, fjs = d.getElementsByTagName(s)[0]; 
if (d.getElementById(id)) return; 
js = d.createElement(s); js.id = id; 
js.src = "//connect.facebook.net/ru_RU/all.js#xfbml=1"; 
fjs.parentNode.insertBefore(js, fjs); 
}(document, 'script', 'facebook-jssdk'));</script>

<header>
	<div class="page">
		
      <div class="jaziki">
        	<a href="/restserver.php" class="rus"> РУС</a>
        	
        </div> 

		<a class="logo" href="/" title=""><img src="/assets/site/img/logo.png" alt="" /></a>
<div class="phone phone_header">	
	<span>044</span> 430-56-22<br/><span>044</span> 430-55-83
<div class="time_header">
<h4>Режим работы отдела продаж</h4>
<p>Пн-Пт: с 8:30 до 17:00</p>
</div>
</div>		
		<div class="text_ru">Завод железобетонных изделий частное акционерное общество Домостроительный комбинат № 4</div>			
	</div>
</header>		
		<section>
			<div class="page2 bot40">
				<div id="left">
					<div class="left-block-bg-top">
</div>
<div class="left-block-bg">
	<nav>
	<ul id="header-nav" class="upper a-style no_dots">
<li>
	<a href="http://dbk4.kiev.ua/"  >Главная</a>
</li>
<li>
	<a href="/produkciya.html"  >Продукция</a>
</li>
<li>
	<a href="/gallereya.html"  >Галерея</a>
</li>
<li>
	<a href="/ogoloshennya.html"  >Вакансии</a>
</li>
<li>
	<a href="/contacts.html"  >Контакты</a>
</li>

</ul>
	</nav>	
</div>
<div class="line-l top10">	
</div>	
<div class="bl-l h1-style top10 p-left5">	
<a class="headakcii" href="akcii.html">Акции и скидки</a>
</div>
<div class="bl-l top10 p-left5">
<ul class="upper a-style no_dots">
<li class="akcii">
	<a href="/akcii/skidka.html"  >На бетон действует гибкая система скидок</a>
</li>
<li class="akcii">
	<a href="/akcii/akciya_2.html"  >Скидки на плиты перекрытия до 12%</a>
</li>

</ul>
</div>				
<div class="line-l top20">	
</div>					
<div class="bl-l h2-style top20 p-left5">Скачать прайс-лист</div>
<div class="down bl-l upper top20"><a onclick="_gaq.push(['_trackEvent', 'Other_sources', 'Price_beton', '', 0]);" href="/download?price=price_beton">Прайс на бетон</a></div>
<div class="down bl-l upper top20"><a onclick="_gaq.push(['_trackEvent', 'Other_sources', 'Price_zhbi', '', 0]);" href="/download?price=price_zb">Прайс на железобетон</a></div>
<div class="down bl-l upper top20"><a onclick="_gaq.push(['_trackEvent', 'Other_sources', 'Price_trans', '', 0]);" href="/download?price=price_mikser">Прайс на доставку</a></div>
<div class="line-l top20">	
</div>				
<div class="bl-l h1-style top40 p-left5">	
	Напишите нам
</div>
<div class="left-block-bg-top top20">
</div>
<div class="left-block-bg left-block-bg2">
<p></p>
<form action="" method="post" id="contactform" >
<input type="hidden" name="formid"  value="contactform" />
	<div class="bl form-zag top5">
		Ваше имя
	</div>
	<div class="bl form-input top3">
		<input type="text" placeholder="Ваше имя:" name="name"  value="" />
	</div>
	<div class="bl form-zag top14">
		Контактный телефон
	</div>
	<div class="bl form-input top3">
		<input type="text" name="phone" placeholder="Ваш телефон:"  value="" />
	</div>
	<div class="bl form-zag top14">
		Ваше сообщение
	</div>
	<div class="bl form-input top3">
		<textarea name="message" placeholder="Сообщение:" style="resize: none" ></textarea>
	</div>
	<div class="bl upper button top14">
		<input type="submit"  value="Отправить" />
	</div>
</form>
</div>

<h4>
<div class="bl-l top10 p-left5">Завод ЖБИ ЧАО "ДСК-4" принимает индивидуальные заказы на изготовление столярных изделий и металлоконструкций</div>
</h4>
				</div>
				<div id="right" class="p2">
<div xmlns:v="http://rdf.data-vocabulary.org/#" class="breadcrumbs"><span class="B_crumbBox"><span class="B_firstCrumb"><span typeof="v:Breadcrumb"><a class="B_homeCrumb" href="/" title="Завод железобетонных конструкций и изделий ЧАО «ДСК-4» — купить бетон в Киеве и области.  Различные виды железобетонных конструкций (ЖБК) и изделий (ЖБИ). Стоимость на сайте."  rel="v:url" property="v:title">Завод ЖБИ №&#10105;</a></span></span> &raquo; <span class="B_lastCrumb"><span typeof="v:Breadcrumb" class="B_currentCrumb">Страница не найдена</span></span></span></div>
					<p><strong>Страница не найдена</strong><br />
Запрашиваемая страница /ads.txt&nbsp;не найдена.&nbsp;<br />
Воспользуйтесь меню, чтобы перейти в нужный раздел.</p>		
				</div>
			</div>							
		</section>
		
		<footer class="top80">
			<div class="footer upper">
	<ul class="ul-style a-style no_dots">
<li><a href="/ua/" >Головна</a></li><i></i>
<li><a href="/ua/produkciya.html" >Продукція</a></li><i></i>
<li><a href="/ua/gallereya.html" >Галерея</a></li><i></i>
<li><a href="/ua/ogoloshennya.html" >Вакансії</a></li><i></i>
<li><a href="/ua/contacts.html" >Контакти</a></li><i></i>

</ul>
	<div class="footer-r">
<div style="margin-right: 20px;"
class="fb-like" data-href="http://dbk4.kiev.ua/" 
data-send="false" data-layout="button_count" data-width="180" 
data-show-faces="false"></div>
© ДБК-4. 2005-2012   Все права защищены<br>
Раскрутка сайта - <a href='http://prodex.ua/' target='_blank'>Prodex</a>
	</div>
</div>			
		</footer>	
<script type="text/javascript" charset="windows-1251" src="http://istat24.com/js/replace.js"></script>
<script type="text/javascript">doReplaceIstat(186);</script>
<!-- Код тега ремаркетинга Google -->
<!--------------------------------------------------
С помощью тега ремаркетинга запрещается собирать информацию, по которой можно идентифицировать личность пользователя. Также запрещается размещать тег на страницах с контентом деликатного характера. Подробнее об этих требованиях и о настройке тега читайте на странице http://google.com/ads/remarketingsetup.
--------------------------------------------------->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 989842753;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/989842753/?value=0&amp;guid=ON&amp;script=0"/>
</div>
</noscript>	
	

</body>
</html>